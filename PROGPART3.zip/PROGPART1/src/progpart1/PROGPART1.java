import javax.swing.JOptionPane;
import java.util.regex.Pattern;
import java.util.Random;

public class PROGPART1 {

    private String username;
    private String password;
    private String phoneNumber;

    static String[] recipients = new String[10];
    static String[] messages = new String[10];
    static String[] flags = new String[10];
    static String[] messageHashes = new String[10];
    static String[] messageIds = new String[10];
    static int messageCount = 0;

    public PROGPART1(String username, String password, String phoneNumber) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }

    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        return password.length() >= 8 &&
               Pattern.compile("[A-Z]").matcher(password).find() &&
               Pattern.compile("[0-9]").matcher(password).find() &&
               Pattern.compile("[!@#$%^&*]").matcher(password).find();
    }

    public boolean checkCellPhoneNumber() {
        return phoneNumber.matches("^\\+27\\d{9}$");
    }

    public String registerUser() {
        if (!checkUserName()) return "❌ Invalid username.";
        if (!checkPasswordComplexity()) return "❌ Weak password.";
        if (!checkCellPhoneNumber()) return "❌ Invalid phone number.";
        return "✅ Registration successful!";
    }

    public boolean loginUser(String u, String p) {
        return this.username.equals(u) && this.password.equals(p);
    }

    public String returnLoginStatus(String u, String p) {
        return loginUser(u, p) ? "✅ Welcome " + u : "❌ Login failed.";
    }

    public static void addMessage(String recipient, String message, String flag) {
        if (messageCount >= 10) return;
        recipients[messageCount] = recipient;
        messages[messageCount] = message;
        flags[messageCount] = flag;
        messageIds[messageCount] = generateMessageId();
        messageHashes[messageCount] = generateMessageHash(message);
        messageCount++;
    }

    public static void sendMessage(int numMessages) {
        for (int i = 0; i < numMessages; i++) {
            String recipient = JOptionPane.showInputDialog("Enter recipient:");
            String message = JOptionPane.showInputDialog("Enter message:");

            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null, "Message too long.");
            } else {
                addMessage(recipient, message, "Sent");
                JOptionPane.showMessageDialog(null, "Message sent!");
            }
        }
    }

    public static String generateMessageId() {
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) sb.append(r.nextInt(10));
        return sb.toString();
    }

    public static String generateMessageHash(String message) {
    String[] words = message.trim().split("\\s+");
    
    if (words.length >= 2) {
        String first = words[0].length() >= 3 ? words[0].substring(0, 3) : words[0];
        String last = words[words.length - 1].length() >= 3 ? words[words.length - 1].substring(0, 3) : words[words.length - 1];
        return (first + last).toUpperCase();
    } else {
        // If only one word or empty message
        String single = words[0];
        return single.substring(0, Math.min(6, single.length())).toUpperCase();
    }
}

    public static void menu() {
        String[] options = {
            "1. Display senders & recipients",
            "2. Display longest message",
            "3. Search by Message ID",
            "4. Search messages for recipient",
            "5. Delete by Message Hash",
            "6. Display full sent report"
        };

        while (true) {
            String choice = (String) JOptionPane.showInputDialog(null, "Choose an option:", "Menu",
                    JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (choice == null) break;

            switch (choice.charAt(0)) {
                case '1': displaySendersAndRecipients(); break;
                case '2': displayLongestMessage(); break;
                case '3':
                    String id = JOptionPane.showInputDialog("Enter Message ID:");
                    searchByMessageId(id); break;
                case '4':
                    String r = JOptionPane.showInputDialog("Enter recipient:");
                    searchMessagesByRecipient(r); break;
                case '5':
                    String h = JOptionPane.showInputDialog("Enter Message Hash:");
                    deleteByMessageHash(h); break;
                case '6': displayReport(); break;
            }
        }
    }

    public static void displaySendersAndRecipients() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageCount; i++) {
            if ("Sent".equalsIgnoreCase(flags[i])) {
                sb.append("Recipient: ").append(recipients[i])
                  .append("\nMessage: ").append(messages[i]).append("\n\n");
            }
        }
        JOptionPane.showMessageDialog(null, sb.length() > 0 ? sb.toString() : "No sent messages.");
    }

    public static void displayLongestMessage() {
        int index = 0;
        for (int i = 1; i < messageCount; i++) {
            if (messages[i].length() > messages[index].length()) index = i;
        }
        JOptionPane.showMessageDialog(null, "Longest message:\n" + messages[index]);
    }

    public static void searchByMessageId(String id) {
        for (int i = 0; i < messageCount; i++) {
            if (messageIds[i] != null && messageIds[i].equals(id)) {
                JOptionPane.showMessageDialog(null, "Recipient: " + recipients[i] + "\nMessage: " + messages[i]);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    public static void searchMessagesByRecipient(String r) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageCount; i++) {
            if (recipients[i] != null && recipients[i].equals(r)) {
                sb.append(messages[i]).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, sb.length() > 0 ? sb.toString() : "No messages.");
    }

    public static void deleteByMessageHash(String hash) {
        for (int i = 0; i < messageCount; i++) {
            if (messageHashes[i] != null && messageHashes[i].equals(hash)) {
                recipients[i] = null;
                messages[i] = null;
                messageHashes[i] = null;
                messageIds[i] = null;
                flags[i] = "Deleted";
                JOptionPane.showMessageDialog(null, "Message deleted.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message hash not found.");
    }

    public static void displayReport() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageCount; i++) {
            if ("Sent".equalsIgnoreCase(flags[i])) {
                sb.append("Hash: ").append(messageHashes[i])
                  .append("\nRecipient: ").append(recipients[i])
                  .append("\nMessage: ").append(messages[i]).append("\n\n");
            }
        }
        JOptionPane.showMessageDialog(null, sb.length() > 0 ? sb.toString() : "No sent messages.");
    }

    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Enter username (_ and ≤ 5 chars):");
        String password = JOptionPane.showInputDialog("Enter password (8+ chars, uppercase, number, special):");
        String phoneNumber = JOptionPane.showInputDialog("Enter phone (+27#########):");

        PROGPART1 user = new PROGPART1(username, password, phoneNumber);
        String registrationResult = user.registerUser();
        JOptionPane.showMessageDialog(null, registrationResult);

        if (!registrationResult.startsWith("✅")) return;

        String loginUsername = JOptionPane.showInputDialog("Login username:");
        String loginPassword = JOptionPane.showInputDialog("Login password:");
        String loginStatus = user.returnLoginStatus(loginUsername, loginPassword);
        JOptionPane.showMessageDialog(null, loginStatus);

        if (loginStatus.startsWith("✅")) {
            int numMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages to send?"));
            sendMessage(numMessages);
            menu();
        }
    }
}


